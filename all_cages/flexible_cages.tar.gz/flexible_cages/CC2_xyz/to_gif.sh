convert -delay 20 -loop 0 -fuzz 10% *_no_box.png all_cc3_cages.gif
echo "see all_cc3_cages.gif"
